/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Admin
 */
public class Matrix {
    public static void main(String[] args) {
        int a [][] = {{1,3,4},{2,4,3},{3,4,5}};
        int b [][] = {{1,3,4},{2,4,3},{1,2,4}};
        
        //creating another matrix to add the sum
        int sum [][] = new int [3][3];//3 rows and 3 columns
        
        //adding and printing 2 matrices
        for (int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                sum[i][j] = a[i][j] + b[i][j];
                System.out.print(sum[i][j]+" ");
            }
            System.out.println("");
        }
    }
}
